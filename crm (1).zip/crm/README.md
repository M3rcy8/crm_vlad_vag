# crm

## swagger

http://localhost:8080/swagger-ui/index.html#/

## rabbitmq

http://localhost:15672/#/